

This repository contains my notes and exercices while following along "Programming In Haskell", the great course by [Graham Hutton](http://www.cs.nott.ac.uk/~pszgmh/).

The course is available on YouTube:
* [Programming In Haskell](https://www.youtube.com/c/GrahamHuttonNotts): 


## Files and Organization

In the app folder, there is one file for each youtube videos (each video corresponds to a course chapter).

When I'm following along the video, I'm using GHCi and `:load` (and :reload) the corresponding file. 
The file contains boths examples and excercies proposed in the corresponding video.
